require('core-js/fn/array/from');
const CircleType = require('./class').default;

module.exports = CircleType;
